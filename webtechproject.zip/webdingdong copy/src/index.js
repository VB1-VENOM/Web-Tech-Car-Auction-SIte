import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import Login from './Logsign';
import Signup from './L2';
import Cardet from './cardetails';
import About from './AboutUs';
import {BrowserRouter,Route,Routes,Link} from "react-router-dom"


ReactDOM.render(
  <React.StrictMode>
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="/about" element={<About />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/Rolls" element={<Cardet name = "Red Rolls Royce" pic = "roll.jp g" horsepower="1000" engine = "v8 " drive = "Raar wheel Drive"/>} />
      <Route path="/Bugatti" element={<Cardet name = "Bugatti Veron" pic = "bugatti.jpg" horsepower="1200" engine = "v9 " drive = "Raar wheel Drive"/>} />
      <Route path="/Ghost" element={<Cardet name = "Ghost" pic = "pic.jpg" horsepower="1400" engine = "v10 " drive = "Raar wheel Drive"/>} />
      <Route path="/Ferrari" element={<Cardet name = "Ferrari" pic = "ferrari.jpg" horsepower="1600" engine = "v11 " drive = "Raar wheel Drive"/>} />
      <Route path="/Lambo" element={<Cardet name = "Lambhorgini" pic = "lambo.jpg" horsepower="1800" engine = "v12 " drive = "Raar wheel Drive"/>} />
      <Route path="/Mustang" element={<Cardet name = "Mustang" pic = "mustang.jpg" horsepower="2000" engine = "v13 " drive = "Raar wheel Drive"/>} />
    </Routes>
  </BrowserRouter>
    
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
