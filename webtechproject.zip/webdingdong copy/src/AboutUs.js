import './logsigh.css';
import React from 'react';
import { Link } from 'react-router-dom';
import {BrowserRouter as Router,Route,Redirect} from 'react-router-dom';
function About()
{
    return(

        <div>
        <div style = {{backgroundColor:"#0F2C67",height : 100}}>
        <h2 style = {{color:"orange",textAlign:'center',position:"relative",top:30}} >About Us</h2>
        </div><br/>
        
        {/* <p id = "n"> Name :
        <input type="text"   id = "Name"></input></p> */}
        <div id = "info">
        <p><b><h3>Ever come across a time where you need to sell  your car?
            Ever dreaded the decision just because of the incredible pain and due diligence that comes with it?

            Finding a buyer, haggling a price, and giving it away- these are the reasons why many hate the process of selling their car. 
            
            We have just made this superbly simple. post your car, place your reserve and look at its prices rise
             and be sold with little effort from your side!
            
            This site has cars ranging from fast super cars to the that budget brawler that you need for work or recreation!


            A huge selection of cars makes this site a one-stop destination to your new car!

            We hope you enjoy this experience!
            </h3>
            </b>
        </p>
        </div>
        
        {/* <p id ="p">Password :
            <input type="password" id="pass"></input>
        </p> */}

        <div style = {{position:'relative',left:200}}><p style={{position:'relative'}}><b><h1> Our team : </h1></b></p>
             <div className = "person">
                 Name : Tanish P
                 <br/>
                 <br/>
                 <img style = {{height:200,width : 200,position:'relative',left:60}} src = "picture.jpg"></img>
             </div>
             <div className = "person">
                 Name : Ujwal KV
                 <br/>
                 <br/>
                 <img style = {{height:200,width : 200,position:'relative',left:60}} src = "ujwal.jpeg"></img>
             </div>
             <div className = "person">
                 Name : Varun S
                 <br/>
                 <br/>
                 <img style = {{height:200,width : 200,position:'relative',left:60}} src = "varun.jpeg"></img>
             </div>
        </div>
        
      
        {/* <p id ="s">
        <button type="submit" style = {{backgroundColor:"red"}}><b>Log in</b>  </button>
        </p>  */}
        
        
        <Link to = "/" style = {{float:"right",color:"green",position:"relative",top:400}}>Return to Home Page
        </Link>

        </div>
    );
}
export default About;