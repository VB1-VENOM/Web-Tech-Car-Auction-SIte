//import './logsigh.css';
import React from 'react';
import { Link } from 'react-router-dom';
import {BrowserRouter as Router,Route,Redirect} from 'react-router-dom';

class App extends Component {
    state={users:[]}
    componentDidMount()
    {
        fetch('users').then(res=>)
    }
}
function Login()
{
    return(
  
 
        <div>
            x<form action="/loginnew" method="POST">
        <h1 >Log in Page</h1>
        
        <p id = "n"> Name :
        <input type="text" id="fullname" name="fullname"></input></p>
        
        <p id ="p">Password :
            <input type="password" id="password" name="password"></input>
        </p>
        
      
        <p id ="s">
        <input type="submit" >Log in </input>
        </p> 
        
        
        <Link to = "/signup">Sign up if you haven't registered
        </Link>
    </form>

        </div>
    );
}
export default Login;