




import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.css';

import './components/styling.css'
class Abc extends Component{
    
    render(){
        
        return(

            <form action="/login" method="POST">  
        <div className = "x1"> 
        <nav>
                <h1 style = {{color:"green"}}>Car Auction Site</h1>
                <a className = "btn1" id="b1" href="http://programminghead.com"></a>
                <input type="submit" />
      <input type="submit" value = "car details"/></a>
      <a className = "btn1" id="b2" href="http://programminghead.com">
      <input type="submit" value = "car details"/></a>
      <a className = "btn1" id="b3" href="C://Users//tanis//OneDrive//Desktop//HTML/13_p3.html">
      <input type="submit" value = "sign-up"/></a>
      <a className = "btn1" id="b4" href="./h.html">
      <input type="submit" value = "log-in"/></a>
        </nav>
        </div>
        </form>
        );
    }
}
