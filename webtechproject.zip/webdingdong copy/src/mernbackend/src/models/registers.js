const mongoose =require("mongoose");

const loginSchema=new mongoose.Schema({
fullname:{
    type:String,
    required:true
},
password:{
    type:String,
    required:true 
}

})

const CarSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    details:{
        type:String,
        required:true 
    },
    picture:{
        type:String,
        required:true 
    },
    highestBid:{
        type:String,
        required:true 
    },
    TimeRemaining:{
        type:String,
        required:true 
    }

    
    })
//we create collections here
const CarRegister=new mongoose.model("Login",CarSchema);
const Register=new mongoose.model("Car",loginSchema);




module.exports= CarRegister;
module.exports= Register;