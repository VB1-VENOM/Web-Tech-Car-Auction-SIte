const express = require('express');
const logger = require('morgan');
const cors = require('cors');
const app=express();


require("./db/conn");
var router = express.Router();
const Register=require("./models/registers");

const CarRegister=require("./models/carregisters");

//use cors to allow cross origin resource sharing
app.use(
  cors({
    origin: 'http://localhost:3000',
    credentials: true,
  })
);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

let cd= [];

app.get('/create', function(req, res) {
  console.log('Inside car det ');
  res.writeHead(200, {
    'Content-Type': 'application/json',
  });
  console.log('cardet : ', JSON.stringify(cd));
  res.end(JSON.stringify(cd));
});

 app.post('/create', function(req, res) {
  const cp = {
    CarName: req.body.CarName,
    Details: req.body.Details,
    HighestBidder:req.body.Owner,
   HighestBid:req.body.bidprice
    
  };

  cd.push(cp);
 console.log(cd);
});
let signupdet =[]
app.get('/sigh', function(req, res) {
  console.log('Inside signup server');
  res.writeHead(200, {
    'Content-Type': 'application/json',
  });
  console.log('signupdet : ', JSON.stringify(signupdet));
  res.end(JSON.stringify(bp));
});

app.post('/sigh', async(req, res)=>{
  try{
    const registerUser= new Register({
        fullname:req.body.username,
        password:req.body.password
    });
    const registered=await registerUser.save();
    
    //console.log(req.body.fullname);
    //res.send(req.body.fullname);
}catch(error){
    res.status(400).send(error);
}
});

// //app.post('/create', async(req, res)=>{
//   //try{
//     const registerUser= new CarRegister({
//         CarName:req.body.CarName,
//         Details:req.body.Details,
//         Owner:req.body.Owner,
//         HighestBid:req.body.bidprice,
//         HighestBidder:req.body.Owner

//     });
//     const registered=await registerUser.save();
    
//     //console.log(req.body.fullname);
//     //res.send(req.body.fullname);
// }catch(error){
//     res.status(400).send(error);
// }
//});
app.post('/create', async(req, res)=>{
  try{
    const registerCar= new CarRegister({
      CarName:req.body.CarName,
              Details:req.body.Details,
               Owner:req.body.Owner,
              HighestBid:req.body.bidprice,
               HighestBidder:req.body.Owner
    });
    const registered=await registerCar.save();
    
    //console.log(req.body.fullname);
    //res.send(req.body.fullname);
}catch(error){
    res.status(400).send(error);
}
});
//login stuff
var name1='';
app.post("/log",async(req,res)=>{
    try{
        const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://localhost:27017';

MongoClient.connect(url, { useNewUrlParser: true }, (err, client) => {

    if (err) throw err;

    const db = client.db("People");

    let collection = db.collection('logins');
    
    let query = { fullname: req.body.username, password:req.body.password};
    console.log(req.body.username);
    collection.findOne(query, function(err, result) {
        if (err) { 
            console.log(err); 
            

        }
    
        if (result) {
             
            
            name1=req.body.username;
            router.get('/log',function(req,res){
              res.sendFile(path.join(__dirname+'/success.html'));
              //__dirname : It will resolve to your project folder.
            });
            console.log('Found');
            
            
         
            
        } else {

          router.get('/log',function(req,res){
            res.sendFile(path.join(__dirname+'/flop.html'));
            //__dirname : It will resolve to your project folder.
          });
          
          
            console.log('Not Found');
            
            
        }
    });
});


console.log(name1);

        
       
    }catch(error){
        res.status(400).send(error);
    }
})

//start your server on port 3001
app.listen(3001, () => {
  console.log('Server Listening on port 3001');
});