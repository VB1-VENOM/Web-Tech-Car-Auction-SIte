import './logsigh.css';
import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
function Signup()
{
    const [input,setInput] = useState({
        username:'',
        password:''
    })

function handleChange(event)
{
  const {name,value} = event.target;

  setInput(prevInput=>{
      return{
          ...prevInput,
          [name]:value
      }
  })
}

function handleClick(event)
{
    event.preventDefault();
    const newUser = {
        username:input.username,
        password:input.password,
    }
    axios.post('http://localhost:3001/sigh',newUser)
    console.log(newUser) 
    setInput({
        username:'',
        password:''
    })
}
    return(
        <div>
        <form class ="form" function='/sigh' method='POST'>
        <div style = {{backgroundColor:"#0F2C67",height : 100}}>
            <h2 style = {{color:"orange",textAlign:'center',position:"relative",top:30}}  >Sign-up Page</h2>
</div>

<p id = "n"> Name :
<input type="text" name='username' value={input.username} onChange={handleChange} id = "Name"></input></p>

<p id ="p">Password :
    <input type="password" name='password' value={input.password} onChange={handleChange} id="pass"></input>
</p>



<div id ="s">
<button type="submit" onClick={handleClick} >Sign in </button>
</div> 
<Link to = "/login" style = {{position:"relative",top:400}}>login if you have already registered</Link>
 <Link to = "/" style = {{float:"right",color:"green",position:"relative",top:400}}>Return to Home Page
        </Link>


</form>

        </div>
    );
}
export default Signup;