const mongoose =require("mongoose");
const CarSchema=new mongoose.Schema({
    CarName:{
        type:String,
        
        required:true
    },
    
    Details:{
        type:String,
        required:true 
    },
    Owner:{
        type:String,
        required:true 
    },
    HighestBid:{
        type:String,
        default: '',
        required:true 
    },

    HighestBidder:{
        type:String,
        default: '',
        required:true 
    }

    
    })
//we create collections here
const CarRegister=new mongoose.model("CarDetails",CarSchema);
module.exports= CarRegister;