
import React,{useState} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './cardetails.css';
import Countdown from 'react-countdown';


class Canvas extends React.Component{
    render(){
        return(<img id = "can" width="700" height="350"  src = {this.props.pic}></img>)
    }
}
class Cardet extends React.Component{
    
        constructor(props) {
          super(props);
      
          this.state = {
            CarName: this.props.name, Details:this.props.engine,Owner:'owner', bidprice:'', HighestBidder:''
          };
        }
        handleInputChange = e => {
          this.setState({
            [e.target.name]: e.target.value,
          });
        };
      
        handleSubmit = e => {
          e.preventDefault();
      
          const { CarName, Details,Owner, bidprice, HighestBidder } = this.state;
      
          const car = {
            CarName, Details,Owner, bidprice, HighestBidder
          };
          axios
          .post('http://localhost:3001/create', car)
          .then(() => console.log('detail update'))
          .catch(err => {
            console.error(err);
          });
        }
        
        
      
    render(){

        return(<div>
        <h1 class = "t1">{this.props.name}</h1>
        <Canvas pic = {this.props.pic} />
        <article>
            <section>
            <p><b>Features : </b></p>
            
            <p>Horsepower : {this.props.horsepower} </p>
            
            <p>Engine : {this.props.engine}</p>
            <p>{this.props.drive}</p>
            </section>
      

        </article>
        <div class = "right" >
            <div class = "box">Current Bid is: {this.state.bidprice}</div><br />
           
            <form action="http://localhost:3001/create" method="POST" className="abc" onSubmit={this.handleSubmit} style ={{
  border: "hidden"}}>
            <div class = "box2">Place your bid :
            <input type = "text" className ="bidprice" name="bidprice" value={this.state.bidprice} onChange={this.handleInputChange}>
             </input>
             <p name="carname" value= "carname">Enter owners name</p>
             
             <input type = "text" className ="owner" name="owner" value={this.state.owner} onChange={this.handleInputChange}/>
             <input type = "text" className ="carname" name="carname" value={this.props.name} onChange={this.handleInputChange}/>
             <input type = "text" className ="details" name="details" value={this.props.engine} onChange={this.handleInputChange}/>
             <button className="btn btn-success" type="submit" onClick={this.handleSubmit} >submit</button>
             <div class = "box">Time remaining : <Countdown date={Date.now() + 9000000} /> </div>
             </div></form><br />
             <div class = "box">Time remaining : <Countdown date={Date.now() + 9000000} /> </div>
        </div>



    

      
    

        </div>)
    }
}
export default Cardet;
 