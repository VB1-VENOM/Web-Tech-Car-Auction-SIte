import './logsigh.css';
import React,{useState} from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import {BrowserRouter as Router,Route,Redirect} from 'react-router-dom';
function Login()
{
    const [input,setInput] = useState({
        username:'',
        password:''
    })

function handleChange(event)
{
  const {name,value} = event.target;

  setInput(prevInput=>{
      return{
          ...prevInput,
          [name]:value
      }
  })
}

function handleClick(event)
{
    event.preventDefault();
    const newUser = {
        username:input.username,
        password:input.password,
    }
    axios.post('http://localhost:3001/log',newUser)
    console.log(newUser) 
    setInput({
        username:'',
        password:''
    })
}
    return(

        <div>
            <form class ="form" function='/log' method='POST'>
            <div style = {{backgroundColor:"#0F2C67",height : 100}}>
        <h2 style = {{color:"orange",textAlign:'center',position:"relative",top:30}}>Log in Page</h2>
        </div>
        <p id = "n"> Name :
        <input type="text"  name='username' value ={input.username} onChange={handleChange} id = "Name"></input></p>
        
        <p id ="p">Password :
            <input type="password" name ='password' value={input.password} onChange={handleChange} id="pass"></input>
        </p>
        
      
        <p id ="s">
        <button type="submit"  onClick={handleClick}>Log in </button>
        </p> 
        
        
        <Link to = "/signup" style = {{position:"relative",top:400}}>Sign up if you haven't registered
        </Link>
        <Link to = "/" style = {{float:"right",color:"green",position:"relative",top:400}}>Return to Home Page
        </Link>
    </form>

        </div>
    );
}
export default Login;