var company = {
    Name: "PES University", Address: "India",
    Contact: "+919876543210", Email: "www.pes.edu"
    };
    // Display the object information
    console.log("Information of variable company:", company);
    // Display the type of variable
    console.log("Type of variable company:", typeof company);
    